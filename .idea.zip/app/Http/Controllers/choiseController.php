<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class choiseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $choise = \DB::select('SELECT * FROM choise');
        return view('choise/index', ['choise'=> $choise]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('choise/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        \DB::table('choise')
            ->insert([
                'name'        => $request->name,
                'description' => $request->description,
                'hours'       => $request->hours,
                'teacher'     => $request->teacher,


            ]);

        return redirect()->route('choise.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $choise = \DB::table('choise')
            ->where('id', $id )
            ->first();

        return view('choise/show', ['choise' => $choise]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $choise = \DB::table('choise')
            ->where('id', $id )
            ->first();
        return view('choise/edit', ['choise' => $choise]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        \DB::table('choise')
            ->where('id', $id)
            ->update([
                'name'        => $request->name,
                'description' => $request->description,
                'hours'       => $request->hours,


            ]);
        return redirect()->route('choise.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        \DB::table('choise')->
           where('id', $id)->delete();
        return redirect()->route('choise.index');
    }
}

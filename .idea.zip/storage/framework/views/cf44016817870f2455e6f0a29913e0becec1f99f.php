<form action="<?php echo e(route('choise.update', $choise->id)); ?>" method="post">
    <input type="hidden" name="_method" value="PUT">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Naam:</label>
        <input type="text" value="<?php echo e($choise->name); ?>" name="name">
    </div>

    <div class="form-group">
        <label for="description">Beschrijving van het keuzedeel:</label>
        <textarea name="description" id="" cols="30" rows="10"><?php echo e($choise->description); ?></textarea>
    </div>

    <div class="form-group">
        <label for="hours">Aantal uren</label>
        <select name="hours" size="3" id="" required>
            <option value="240">240</option>
            <option value="480">480</option>
            <option value="720">720</option>
        </select>
    </div>
    <div class="form-group">
        <label for="teacher">teacher</label>
        <input type="text" name="teacher">
    </div>
    <div class="form-group">
        <input type="submit" value="Pas dit keuzedeel aan">
    </div>
</form>




<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/choise/edit.blade.php ENDPATH**/ ?>
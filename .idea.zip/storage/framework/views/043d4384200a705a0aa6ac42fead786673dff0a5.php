<form action="<?php echo e(route('choise.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Naam:</label>
        <input type="text" name="name">
    </div>

    <div class="form-group">
        <label for="description">Beschrijving van het keuzedeel:</label>
        <textarea name="description" id="" cols="30" rows="10"></textarea>
    </div>

    <div class="form-group">
        <label for="hours">Aantal uren</label>
        <select name="hours" size="3" id="">
            <option value="240">240</option>
            <option value="480">480</option>
            <option value="720">720</option>
        </select>
    </div>
    Docent kun je later toevoegen
    <div class="form-group">
        <label for="teacher">docent</label>
        <input type="text" name="teacher">
    </div>
    <div class="form-group">
        <input type="submit" value="Maak keuzedeel aan">
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/choise/create.blade.php ENDPATH**/ ?>
<?php
require '../config.php';
//session_start();
//if (isset($_SESSION["username"])){
  //  echo '<h3>Inloggen gelukt, welkom - '.$_SESSION["username"].'</h3>';
//}
//else{
  //  header("/");
//}
?>
wilt u een nieuw keuze deel aanmaken?<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/docent.blade.php ENDPATH**/ ?>
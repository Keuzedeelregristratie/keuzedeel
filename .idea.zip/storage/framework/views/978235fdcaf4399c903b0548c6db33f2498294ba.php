<?php
require '../config.php';
?>

Hoi student
Maak je keuze voor het keuzedeel<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/student.blade.php ENDPATH**/ ?>
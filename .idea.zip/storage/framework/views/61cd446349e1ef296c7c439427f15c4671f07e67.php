
<h1>Keuzedelen</h1>
<ul>
    <?php $__currentLoopData = $choise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choises): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('choisestudent.show', $choises->id)); ?>"> <?php echo e($choises->name); ?> </a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<form action="<?php echo e(route('choisestudent.index')); ?>">
    <input type="submit" value="Maak hier je keuze voor je keuzedeel">
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/choisestudent/index.blade.php ENDPATH**/ ?>

<form action="<?php echo e(route('education.update', $educations->id)); ?>" method="post">
    <input type="hidden" name="_method" value="PUT">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Naam:</label>
        <input type="text" value="<?php echo e($educations->name); ?>" name="name">
    </div>

    <div class="form-group">
        <label for="crebonumber">crebonummer van deze opleiding:</label>
        <input type="number" value="<?php echo e($educations->crebonumber); ?>" name="crebonumber">
    </div>

    <div class="form-group">
        <input type="submit" value="Pas deze opleiding aan">
    </div>
</form>

<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/education/edit.blade.php ENDPATH**/ ?>
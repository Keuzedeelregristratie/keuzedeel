hallo student
<form action="<?php echo e(route('choisestudent.index')); ?>">
    <input type="submit" value="vind informatie over je keuzedelen">
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/student/store.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: right;
        }

        .title {
            font-size: 40px;
            text-align: center;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        input[type=submit]{
            justify-content: center;
            display: flex;
            align-items: center;
            height: 100%;
            width: 57%;
            margin-left: 120px;
        }

        .navigatie a{
            display: inline-block;
            color: black;
            text-align: center;
            padding: 0 50px  0 0;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>"></a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>"></a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>"></a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="content">
        <div class="navigatie">
            <a href="<?php echo e(route('login.index')); ?>">Docent</a>
            <a href="<?php echo e(route('student.index')); ?>">Student</a>
        </div>
        <div class="title m-b-md">
            Login Student
        </div>

        <div class="login">
            <form action="<?php echo e(route('student.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <p>Gebruikersnaam:
                    <input type="text" name="username" id="username" required>
                </p>
                <p>Wachtwoord:
                    <input type="password" name="password" id="password" required>
                </p>
                <input type="submit" name="login" value="Login" id="login-button">
                <p><a href="<?php echo e(route('forgetstudent.index')); ?>">Wachtwoord vergeten</a></p>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/student/index.blade.php ENDPATH**/ ?>
<h1>Keuzedelen</h1>
<ul>
    <?php $__currentLoopData = $choise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choises): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('choise.show', $choises->id)); ?>"> <?php echo e($choises->name); ?> </a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<form action="<?php echo e(route('choise.create')); ?>">
    <input type="submit" value="Maak keuzedeel aan">
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/choise/index.blade.php ENDPATH**/ ?>
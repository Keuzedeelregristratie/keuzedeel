<form action="<?php echo e(route('education.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Naam van de opleiding:</label>
        <input type="text" name="name">
    </div>

    <div class="form-group">
        <label for="crebonumber">voeg hier het crebo nummer in van de opleiding:</label>
        <input type="number" name="crebonumber">
    </div>

    <div class="form-group">
        <input type="submit" value="Maak opleiding aan">
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/education/create.blade.php ENDPATH**/ ?>
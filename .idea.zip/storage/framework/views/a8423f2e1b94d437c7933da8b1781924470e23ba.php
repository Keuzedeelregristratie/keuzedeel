hallo docent

<form action="<?php echo e(route('choise.index')); ?>">
    <input type="submit" value="Overzicht keuzedelen">
</form>

<form action="<?php echo e(route('education.index')); ?>">
    <input type="submit" value="Overzicht opleidingen">
</form>

<form action="#">
    <input type="submit" value="Voeg studenten toe">
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/login/store.blade.php ENDPATH**/ ?>
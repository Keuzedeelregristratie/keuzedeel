<h1>Opleidingen</h1>
<ul>
    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('education.show', $education->id)); ?>"> <?php echo e($education->name); ?> </a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<form action="<?php echo e(route('education.create')); ?>">
    <input type="submit" value="Maak een opleiding aan aan">
</form>
<?php /**PATH C:\xampp\htdocs\laravel2019\keuzedeel_registratie\resources\views/education/index.blade.php ENDPATH**/ ?>

<form action="{{route('education.update', $educations->id)}}" method="post">
    <input type="hidden" name="_method" value="PUT">
    @csrf
    <div class="form-group">
        <label for="name">Naam:</label>
        <input type="text" value="{{$educations->name}}" name="name">
    </div>

    <div class="form-group">
        <label for="crebonumber">crebonummer van deze opleiding:</label>
        <input type="number" value="{{$educations->crebonumber}}" name="crebonumber">
    </div>

    <div class="form-group">
        <input type="submit" value="Pas deze opleiding aan">
    </div>
</form>


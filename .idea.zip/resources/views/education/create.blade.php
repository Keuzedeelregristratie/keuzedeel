<form action="{{route('education.store')}}" method="post">
    @csrf
    <div class="form-group">
        <label for="name">Naam van de opleiding:</label>
        <input type="text" name="name">
    </div>

    <div class="form-group">
        <label for="crebonumber">voeg hier het crebo nummer in van de opleiding:</label>
        <input type="number" name="crebonumber">
    </div>

    <div class="form-group">
        <input type="submit" value="Maak opleiding aan">
    </div>
</form>

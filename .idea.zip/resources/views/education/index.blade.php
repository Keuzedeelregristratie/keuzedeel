<h1>Opleidingen</h1>
<ul>
    @foreach($educations as $education)
        <li><a href="{{ route('education.show', $education->id)}}"> {{$education->name}} </a></li>
    @endforeach
</ul>
<form action="{{route('education.create')}}">
    <input type="submit" value="Maak een opleiding aan aan">
</form>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<h1>Name:   {{$choise->name}}</h1>
<h2>Description:    {{$choise->description}}</h2>
<h2>aantal uren: {{$choise->hours}}</h2>
<h2>Docent:  {{$choise->teacher}}</h2>

<form action="{{route('choisestudent.index')}}">
    <input type="submit" value="Ga terug naar het overzicht met keuzedelen">
</form>
</body>
</html>

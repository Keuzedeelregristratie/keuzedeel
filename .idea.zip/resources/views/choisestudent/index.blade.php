
<h1>Keuzedelen</h1>
<ul>
    @foreach($choise as $choises)
        <li><a href="{{ route('choisestudent.show', $choises->id)}}"> {{$choises->name}} </a></li>
    @endforeach
</ul>

<form action="{{route('choisestudent.index')}}">
    <input type="submit" value="Maak hier je keuze voor je keuzedeel">
</form>

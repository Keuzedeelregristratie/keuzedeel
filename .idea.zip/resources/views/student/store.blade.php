hallo student
<form action="{{route('choisestudent.index')}}">
    <input type="submit" value="vind informatie over je keuzedelen">
</form>

<?php
require '../config.php';

session_start();

try{
    if(isset($_POST["login"]))
    {
        if(empty($_POST["username"]) || empty($_POST["password"])){
            $message = '<label>Alle velden zijn verplicht</label>';
        }
        else{
            $query = "SELECT * FROM teachers WHERE username = :username AND password = :password";
            $statment = $db->prepare($query);
            $statment->execute(
                array(
                    'username' => $_POST["username"],
                    'password' => $_POST["password"]
                )
            );
            $count = $statment->rowCount();
            if ($count > 0){
                $_SESSION["username"] = $_POST["username"];
            }
            else{
                $message = '<label>verkeerde Gegevens</label>';
            }
        }
    }
}
catch(PDOException $error) {
    $message = $error->getMessage();

}

?>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: right;
            }

            .title {
                font-size: 40px;
                text-align: center;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            input[type=submit]{
                justify-content: center;
                display: flex;
                align-items: center;
                height: 100%;
                width: 57%;
                margin-left: 120px;
            }

            .navigatie a{
                display: inline-block;
                color: black;
                text-align: center;
                padding: 0 50px  0 0;
                text-decoration: none;
                font-size: 100px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}"></a>
                    @else
                        <a href="{{ route('login') }}"></a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}"></a>
                        @endif
                    @endauth
                </div>
            @endif
            <?php
            if(isset($message)){
                echo '<label class="text-danger">'.$message.'</label>';
            }
                ?>
            <div class="content">

                <div class="title m-b-md">
                    Klik op uw keuze om door te gaan naar uw inlogscherm
                </div>
                <div class="navigatie">
                    <a href="{{route('login.index')}}">Docent</a>
                    <a href="{{route('student.index')}}">Student</a>
                </div>

                    </div>
                </div>

            </div>
        </div>
    </body>
</html>


<?php

?>
<h1>Keuzedelen</h1>
<ul>
    @foreach($choise as $choises)
        <li><a href="{{ route('choise.show', $choises->id)}}"> {{$choises->name}} </a></li>
    @endforeach
</ul>
<form action="{{route('choise.create')}}">
    <input type="submit" value="Maak keuzedeel aan">
</form>

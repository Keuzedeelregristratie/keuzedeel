hallo docent

<form action="{{route('choise.index')}}">
    <input type="submit" value="Overzicht keuzedelen">
</form>

<form action="{{route('education.index')}}">
    <input type="submit" value="Overzicht opleidingen">
</form>

<form action="#">
    <input type="submit" value="Voeg studenten toe">
</form>
